--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE chirpstack;
ALTER ROLE chirpstack WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:vGhT2G76gmLw1lGgG/XV2g==$R1G5Xs1HImCeMgOorm0rIN9trxiWpl3d+mY6MolqG/c=:pqH+sVZuQeOW+PcwhIpKibyte0wcutdIHQ+hUPZBWqw=';






--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17
-- Dumped by pg_dump version 14.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "chirpstack" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17
-- Dumped by pg_dump version 14.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: chirpstack; Type: DATABASE; Schema: -; Owner: chirpstack
--

CREATE DATABASE chirpstack WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE chirpstack OWNER TO chirpstack;

\connect chirpstack

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __diesel_schema_migrations; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.__diesel_schema_migrations (
    version character varying(50) NOT NULL,
    run_on timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.__diesel_schema_migrations OWNER TO chirpstack;

--
-- Name: api_key; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.api_key (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    is_admin boolean NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.api_key OWNER TO chirpstack;

--
-- Name: application; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.application (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    mqtt_tls_cert bytea,
    tags jsonb NOT NULL
);


ALTER TABLE public.application OWNER TO chirpstack;

--
-- Name: application_integration; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.application_integration (
    application_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    configuration jsonb NOT NULL
);


ALTER TABLE public.application_integration OWNER TO chirpstack;

--
-- Name: device; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.device (
    dev_eui bytea NOT NULL,
    application_id uuid NOT NULL,
    device_profile_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone,
    scheduler_run_after timestamp with time zone,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    external_power_source boolean NOT NULL,
    battery_level numeric(5,2),
    margin integer,
    dr smallint,
    latitude double precision,
    longitude double precision,
    altitude real,
    dev_addr bytea,
    enabled_class character(1) NOT NULL,
    skip_fcnt_check boolean NOT NULL,
    is_disabled boolean NOT NULL,
    tags jsonb NOT NULL,
    variables jsonb NOT NULL,
    join_eui bytea NOT NULL,
    secondary_dev_addr bytea,
    device_session bytea
);


ALTER TABLE public.device OWNER TO chirpstack;

--
-- Name: device_keys; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.device_keys (
    dev_eui bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    nwk_key bytea NOT NULL,
    app_key bytea NOT NULL,
    dev_nonces jsonb NOT NULL,
    join_nonce integer NOT NULL
);


ALTER TABLE public.device_keys OWNER TO chirpstack;

--
-- Name: device_profile; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.device_profile (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(10) NOT NULL,
    mac_version character varying(10) NOT NULL,
    reg_params_revision character varying(20) NOT NULL,
    adr_algorithm_id character varying(100) NOT NULL,
    payload_codec_runtime character varying(20) NOT NULL,
    uplink_interval integer NOT NULL,
    device_status_req_interval integer NOT NULL,
    supports_otaa boolean NOT NULL,
    supports_class_b boolean NOT NULL,
    supports_class_c boolean NOT NULL,
    class_b_timeout integer NOT NULL,
    class_b_ping_slot_nb_k integer NOT NULL,
    class_b_ping_slot_dr smallint NOT NULL,
    class_b_ping_slot_freq bigint NOT NULL,
    class_c_timeout integer NOT NULL,
    abp_rx1_delay smallint NOT NULL,
    abp_rx1_dr_offset smallint NOT NULL,
    abp_rx2_dr smallint NOT NULL,
    abp_rx2_freq bigint NOT NULL,
    tags jsonb NOT NULL,
    payload_codec_script text NOT NULL,
    flush_queue_on_activate boolean NOT NULL,
    description text NOT NULL,
    measurements jsonb NOT NULL,
    auto_detect_measurements boolean NOT NULL,
    region_config_id character varying(100),
    is_relay boolean NOT NULL,
    is_relay_ed boolean NOT NULL,
    relay_ed_relay_only boolean NOT NULL,
    relay_enabled boolean NOT NULL,
    relay_cad_periodicity smallint NOT NULL,
    relay_default_channel_index smallint NOT NULL,
    relay_second_channel_freq bigint NOT NULL,
    relay_second_channel_dr smallint NOT NULL,
    relay_second_channel_ack_offset smallint NOT NULL,
    relay_ed_activation_mode smallint NOT NULL,
    relay_ed_smart_enable_level smallint NOT NULL,
    relay_ed_back_off smallint NOT NULL,
    relay_ed_uplink_limit_bucket_size smallint NOT NULL,
    relay_ed_uplink_limit_reload_rate smallint NOT NULL,
    relay_join_req_limit_reload_rate smallint NOT NULL,
    relay_notify_limit_reload_rate smallint NOT NULL,
    relay_global_uplink_limit_reload_rate smallint NOT NULL,
    relay_overall_limit_reload_rate smallint NOT NULL,
    relay_join_req_limit_bucket_size smallint NOT NULL,
    relay_notify_limit_bucket_size smallint NOT NULL,
    relay_global_uplink_limit_bucket_size smallint NOT NULL,
    relay_overall_limit_bucket_size smallint NOT NULL,
    allow_roaming boolean NOT NULL,
    rx1_delay smallint NOT NULL
);


ALTER TABLE public.device_profile OWNER TO chirpstack;

--
-- Name: device_profile_template; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.device_profile_template (
    id text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    vendor character varying(100) NOT NULL,
    firmware character varying(100) NOT NULL,
    region character varying(10) NOT NULL,
    mac_version character varying(10) NOT NULL,
    reg_params_revision character varying(20) NOT NULL,
    adr_algorithm_id character varying(100) NOT NULL,
    payload_codec_runtime character varying(20) NOT NULL,
    payload_codec_script text NOT NULL,
    uplink_interval integer NOT NULL,
    device_status_req_interval integer NOT NULL,
    flush_queue_on_activate boolean NOT NULL,
    supports_otaa boolean NOT NULL,
    supports_class_b boolean NOT NULL,
    supports_class_c boolean NOT NULL,
    class_b_timeout integer NOT NULL,
    class_b_ping_slot_nb_k integer NOT NULL,
    class_b_ping_slot_dr smallint NOT NULL,
    class_b_ping_slot_freq bigint NOT NULL,
    class_c_timeout integer NOT NULL,
    abp_rx1_delay smallint NOT NULL,
    abp_rx1_dr_offset smallint NOT NULL,
    abp_rx2_dr smallint NOT NULL,
    abp_rx2_freq bigint NOT NULL,
    tags jsonb NOT NULL,
    measurements jsonb NOT NULL,
    auto_detect_measurements boolean NOT NULL
);


ALTER TABLE public.device_profile_template OWNER TO chirpstack;

--
-- Name: device_queue_item; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.device_queue_item (
    id uuid NOT NULL,
    dev_eui bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    f_port smallint NOT NULL,
    confirmed boolean NOT NULL,
    data bytea NOT NULL,
    is_pending boolean NOT NULL,
    f_cnt_down bigint,
    timeout_after timestamp with time zone,
    is_encrypted boolean NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.device_queue_item OWNER TO chirpstack;

--
-- Name: gateway; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.gateway (
    gateway_id bytea NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    altitude real NOT NULL,
    stats_interval_secs integer NOT NULL,
    tls_certificate bytea,
    tags jsonb NOT NULL,
    properties jsonb NOT NULL
);


ALTER TABLE public.gateway OWNER TO chirpstack;

--
-- Name: multicast_group; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.multicast_group (
    id uuid NOT NULL,
    application_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    region character varying(10) NOT NULL,
    mc_addr bytea NOT NULL,
    mc_nwk_s_key bytea NOT NULL,
    mc_app_s_key bytea NOT NULL,
    f_cnt bigint NOT NULL,
    group_type character(1) NOT NULL,
    dr smallint NOT NULL,
    frequency bigint NOT NULL,
    class_b_ping_slot_nb_k smallint NOT NULL,
    class_c_scheduling_type character varying(20) NOT NULL
);


ALTER TABLE public.multicast_group OWNER TO chirpstack;

--
-- Name: multicast_group_device; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.multicast_group_device (
    multicast_group_id uuid NOT NULL,
    dev_eui bytea NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.multicast_group_device OWNER TO chirpstack;

--
-- Name: multicast_group_gateway; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.multicast_group_gateway (
    multicast_group_id uuid NOT NULL,
    gateway_id bytea NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.multicast_group_gateway OWNER TO chirpstack;

--
-- Name: multicast_group_queue_item; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.multicast_group_queue_item (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    scheduler_run_after timestamp with time zone NOT NULL,
    multicast_group_id uuid NOT NULL,
    gateway_id bytea NOT NULL,
    f_cnt bigint NOT NULL,
    f_port smallint NOT NULL,
    data bytea NOT NULL,
    emit_at_time_since_gps_epoch bigint,
    expires_at timestamp with time zone
);


ALTER TABLE public.multicast_group_queue_item OWNER TO chirpstack;

--
-- Name: relay_device; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.relay_device (
    relay_dev_eui bytea NOT NULL,
    dev_eui bytea NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.relay_device OWNER TO chirpstack;

--
-- Name: relay_gateway; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.relay_gateway (
    tenant_id uuid NOT NULL,
    relay_id bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    stats_interval_secs integer NOT NULL,
    region_config_id character varying(100) NOT NULL
);


ALTER TABLE public.relay_gateway OWNER TO chirpstack;

--
-- Name: tenant; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.tenant (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    can_have_gateways boolean NOT NULL,
    max_device_count integer NOT NULL,
    max_gateway_count integer NOT NULL,
    private_gateways_up boolean NOT NULL,
    private_gateways_down boolean NOT NULL,
    tags jsonb NOT NULL
);


ALTER TABLE public.tenant OWNER TO chirpstack;

--
-- Name: tenant_user; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public.tenant_user (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_admin boolean NOT NULL,
    is_device_admin boolean NOT NULL,
    is_gateway_admin boolean NOT NULL
);


ALTER TABLE public.tenant_user OWNER TO chirpstack;

--
-- Name: user; Type: TABLE; Schema: public; Owner: chirpstack
--

CREATE TABLE public."user" (
    id uuid NOT NULL,
    external_id text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_admin boolean NOT NULL,
    is_active boolean NOT NULL,
    email text NOT NULL,
    email_verified boolean NOT NULL,
    password_hash character varying(200) NOT NULL,
    note text NOT NULL
);


ALTER TABLE public."user" OWNER TO chirpstack;

--
-- Data for Name: __diesel_schema_migrations; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.__diesel_schema_migrations (version, run_on) FROM stdin;
00000000000000	2025-03-19 09:22:31.869593
20220426153628	2025-03-19 09:22:32.018111
20220428071028	2025-03-19 09:22:32.02056
20220511084032	2025-03-19 09:22:32.022765
20220614130020	2025-03-19 09:22:32.044837
20221102090533	2025-03-19 09:22:32.047567
20230103201442	2025-03-19 09:22:32.050135
20230112130153	2025-03-19 09:22:32.051824
20230206135050	2025-03-19 09:22:32.053328
20230213103316	2025-03-19 09:22:32.063867
20230216091535	2025-03-19 09:22:32.06654
20230925105457	2025-03-19 09:22:32.082686
20231019142614	2025-03-19 09:22:32.085333
20231122120700	2025-03-19 09:22:32.089227
20240207083424	2025-03-19 09:22:32.092189
20240326134652	2025-03-19 09:22:32.101144
20240430103242	2025-03-19 09:22:32.114734
20240613122655	2025-03-19 09:22:32.116502
20240916123034	2025-03-19 09:22:32.126271
20241112135745	2025-03-19 09:22:32.128448
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.api_key (id, created_at, name, is_admin, tenant_id) FROM stdin;
\.


--
-- Data for Name: application; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.application (id, tenant_id, created_at, updated_at, name, description, mqtt_tls_cert, tags) FROM stdin;
d64bc6ac-893f-4a49-a140-032fcca79075	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-19 10:19:53.851183+00	2025-03-19 10:19:53.851183+00	atelier_dt		\N	{}
\.


--
-- Data for Name: application_integration; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.application_integration (application_id, kind, created_at, updated_at, configuration) FROM stdin;
d64bc6ac-893f-4a49-a140-032fcca79075	Http	2025-04-02 08:09:06.7199+00	2025-04-07 06:51:06.528642+00	{"Http": {"json": true, "headers": {"Content-Type": "application/json"}, "event_endpoint_url": "http://10.130.1.102:4225/api/lora-weather,http://10.130.1.100:5050/api/data"}}
\.


--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.device (dev_eui, application_id, device_profile_id, created_at, updated_at, last_seen_at, scheduler_run_after, name, description, external_power_source, battery_level, margin, dr, latitude, longitude, altitude, dev_addr, enabled_class, skip_fcnt_check, is_disabled, tags, variables, join_eui, secondary_dev_addr, device_session) FROM stdin;
\\xa84041e731896423	d64bc6ac-893f-4a49-a140-032fcca79075	1f406b44-9ea4-45d5-888a-e4cbf16d04a7	2025-03-28 14:13:27.947461+00	2025-03-28 14:13:27.947461+00	2025-04-08 14:02:47.365975+00	\N	LA779366		f	100.00	6	5	\N	\N	\N	\\x01d59ae8	A	f	f	{}	{}	\\xa840410000000101	\N	\\x120401d59ae820032a10648d110da5093875efd30f6a11efef263210648d110da5093875efd30f6a11efef263a10648d110da5093875efd30f6a11efef26421212108a766083a6a073337fcb90b59e48e65748cb0150c8017001880188cccf9e0392010800010203040506079a010c0806120808a09ae09d0318059a010c0804120808a0e5c79d0318059a010c0803120808e0cabb9d0318059a010c0807120808e0b4ec9d0318059a010c0805120808e0ffd39d031805b00101b80101c00107c80105d00101f2011708b70115000058411807200128eaffffffffffffffff01f2011708b80115333363411807200128d8ffffffffffffffff01f2011708b90115000038411807200128d9ffffffffffffffff01f2011708ba0115000010411807200128e9ffffffffffffffff01f2011708bb0115cdcc3c411807200128e7ffffffffffffffff01f2011708bc0115cdcc5c411807200128d9ffffffffffffffff01f2011708bd0115000030411807200128d7ffffffffffffffff01f2011708be0115000038411807200128e8ffffffffffffffff01f2011708bf0115000060411807200128e8ffffffffffffffff01f2011708c00115333363411807200128d6ffffffffffffffff01f2011708c10115333313411807200128d1ffffffffffffffff01f2011708c20115000000411807200128e2ffffffffffffffff01f2011708c30115000008411807200128e6ffffffffffffffff01f2011708c40115cdcc5c411807200128d6ffffffffffffffff01f2011708c50115cdcc5c411807200128d6ffffffffffffffff01f2011708c60115000060411807200128d6ffffffffffffffff01f2011708c70115cdcc5c411807200128e8ffffffffffffffff01f2011708c80115cdcc5c411807200128d7ffffffffffffffff01f2011708c90115000038411807200128d7ffffffffffffffff01f2011708ca0115000058411807200128d6ffffffffffffffff0182020c08dbc7d4bf0610fac9f5df01c202056575383638
\\xa84041f491895ca6	d64bc6ac-893f-4a49-a140-032fcca79075	87d0f0d9-2600-42e9-b4d4-5a7cf523656f	2025-03-25 11:45:07.700388+00	2025-03-25 11:50:23.715869+00	2025-04-08 14:01:11.820707+00	\N	LA779366		f	94.48	5	5	\N	\N	\N	\\x007b8995	A	f	f	{}	{}	\\xa840410000000101	\N	\\x1204007b899520032a1000a89b7221aefa4db06a18cf8e900710321000a89b7221aefa4db06a18cf8e9007103a1000a89b7221aefa4db06a18cf8e90071042121210ffb8c515466f239cf252dc4f6785ed7048ba1150df107001880188cccf9e0392010800010203040506079a010c0805120808e0ffd39d0318059a010c0803120808e0cabb9d0318059a010c0806120808a09ae09d0318059a010c0804120808a0e5c79d0318059a010c0807120808e0b4ec9d031805b00101b80101c00107c80105d00101f2011708b41115cdcc5c411807200128c4ffffffffffffffff01f2011708b51115333353411807200128d5ffffffffffffffff01f2011708b61115000050411807200128c6ffffffffffffffff01f2011708b71115cdcc1c411807200128b2ffffffffffffffff01f2011708b81115000028411807200128d7ffffffffffffffff01f2011708b91115000000411807200128d5ffffffffffffffff0182020c089d91d3bf0610c39486ec01c202056575383638
\\xa84041e5c1896413	d64bc6ac-893f-4a49-a140-032fcca79075	b5c9b055-c364-41ae-87b9-267cf3ab1d76	2025-03-19 10:28:36.442067+00	2025-03-19 10:36:47.773404+00	2025-04-08 14:01:10.085703+00	\N	LA781267	traffic light	f	99.60	6	5	\N	\N	\N	\\x01a4e54f	A	f	f	{}	{}	\\xa840410000000101	\N	\\x120401a4e54f20032a10145a214f35e2e5af35f876874941efcb3210145a214f35e2e5af35f876874941efcb3a10145a214f35e2e5af35f876874941efcb421212102e3e0fe621374cc7981d94fe38c8fb774861505f7001880188cccf9e0392010800010203040506079a010c0805120808e0ffd39d0318059a010c0806120808a09ae09d0318059a010c0803120808e0cabb9d0318059a010c0807120808e0b4ec9d0318059a010c0804120808a0e5c79d031805b00101b80101c00107c80105d00101f20116085515000060411807200128dbffffffffffffffff01f20116085615333353411807200128d8ffffffffffffffff01f20116085715000030411807200128d0ffffffffffffffff01f20116085815333353411807200128cfffffffffffffffff01f201160859156666c6401807200128dfffffffffffffffff01f20116085a15000058411807200128cfffffffffffffffff01f20116085b15000038411807200128ccffffffffffffffff01f20116085c15000058411807200128d1ffffffffffffffff01f20116085d15000058411807200128deffffffffffffffff01f20116085e15cdcc5c411807200128c7ffffffffffffffff01f20116085f15333333411807200128c7ffffffffffffffff01f20116086015000030411807200128c2ffffffffffffffff0182020b08edd1d4bf0610b4b7cc7fc202056575383638
\.


--
-- Data for Name: device_keys; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.device_keys (dev_eui, created_at, updated_at, nwk_key, app_key, dev_nonces, join_nonce) FROM stdin;
\\xa84041e731896423	2025-03-28 14:13:34.298348+00	2025-04-08 13:25:37.712238+00	\\x1b39e4c4ef0b4038c085804081f9f6e4	\\x00000000000000000000000000000000	{"a840410000000101": [57078, 23339, 41551, 35015, 18934, 5656, 12156, 27069, 210, 51613, 64459, 5477, 11815, 41406, 948, 15400, 1021, 62598, 15319, 16541, 8729, 63882, 13020, 8806, 41934, 3534, 37645, 39009, 39147, 35996, 55424, 64430, 38996, 7521, 58548, 9883, 37462, 28090, 59720, 13542, 18870, 7585, 27976, 12018, 3008, 29499, 40424, 34560, 1656, 64085, 17156, 1282, 20849, 32457, 41607, 33295, 15459, 50022, 47233, 63374, 43191, 2638, 53606]}	63
\\xa84041e5c1896413	2025-03-19 10:37:04.876781+00	2025-04-08 13:47:18.49615+00	\\xdb7950a39a39e0f52928b985370a11f7	\\x00000000000000000000000000000000	{"a840410000000101": [64726, 48212, 40122, 28742, 23531, 53952, 34401, 51680, 19433, 51728, 2859, 46043, 18633, 44989, 22659, 59212, 62626, 4839, 56227, 8380, 11764, 63732, 21666, 11470, 18198, 65156, 46764, 55961, 48155, 21751, 14097, 21888, 32060, 15462, 3965, 34780, 47307, 59454, 3949, 50794, 8804, 25644, 31690, 19747, 39357, 8416, 32740, 18505, 40531, 16011, 39912, 23291, 25227, 24531, 34188, 47459, 12639, 63127, 36986, 41284, 53705, 24799, 14769, 8111, 5266, 61185, 2472, 17805, 32595, 20676, 53238, 45884, 49042, 43280, 49429, 25769, 24483, 63236, 26505, 24540, 64808, 48583, 53392, 5273, 22246, 27432, 6462, 42506, 9367, 44958, 17988, 22886, 57670, 22871, 48883, 20458, 51550, 63255, 35541, 38915, 13143, 50389, 14036, 55236, 36546, 35245, 31773, 62876, 6150, 45519, 25882, 25832, 30543, 16192, 41316, 56977, 11480, 6362, 18687, 21345, 53141, 7677, 50978, 36683, 15806, 21105]}	126
\\xa84041f491895ca6	2025-03-25 11:50:08.357366+00	2025-04-08 06:56:22.477806+00	\\x5eddda74828bbefc540662d5ce571986	\\x00000000000000000000000000000000	{"a840410000000101": [41937, 46845, 61926, 44200, 21052, 42203, 25926, 31750, 39897, 50169, 7862, 10962, 39393, 30757, 43845, 12293, 13702, 49783, 18650, 11442, 3319, 37785, 17189, 47594, 44915, 20738, 21429, 49648, 32522, 25314, 18405, 31972, 26371, 22858, 52230, 42640, 38918, 13441, 1245, 40879, 5945, 59750, 25629, 28011, 34515, 48298, 28259, 62028, 11912, 13323, 62792, 1823, 48766, 59401, 63685, 49581, 38439, 56031, 11074, 8420, 14909, 50753, 65376, 13003, 25, 54206, 23132, 59082, 11876, 36766, 2921, 42620, 64688, 22136, 23549, 54964, 43611, 24637, 23179, 28486, 51038, 48823, 51478, 9057, 63339]}	85
\.


--
-- Data for Name: device_profile; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.device_profile (id, tenant_id, created_at, updated_at, name, region, mac_version, reg_params_revision, adr_algorithm_id, payload_codec_runtime, uplink_interval, device_status_req_interval, supports_otaa, supports_class_b, supports_class_c, class_b_timeout, class_b_ping_slot_nb_k, class_b_ping_slot_dr, class_b_ping_slot_freq, class_c_timeout, abp_rx1_delay, abp_rx1_dr_offset, abp_rx2_dr, abp_rx2_freq, tags, payload_codec_script, flush_queue_on_activate, description, measurements, auto_detect_measurements, region_config_id, is_relay, is_relay_ed, relay_ed_relay_only, relay_enabled, relay_cad_periodicity, relay_default_channel_index, relay_second_channel_freq, relay_second_channel_dr, relay_second_channel_ack_offset, relay_ed_activation_mode, relay_ed_smart_enable_level, relay_ed_back_off, relay_ed_uplink_limit_bucket_size, relay_ed_uplink_limit_reload_rate, relay_join_req_limit_reload_rate, relay_notify_limit_reload_rate, relay_global_uplink_limit_reload_rate, relay_overall_limit_reload_rate, relay_join_req_limit_bucket_size, relay_notify_limit_bucket_size, relay_global_uplink_limit_bucket_size, relay_overall_limit_bucket_size, allow_roaming, rx1_delay) FROM stdin;
d2d33e47-168a-4215-966d-2c6c6498bf5c	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-19 10:52:08.811696+00	2025-03-19 10:55:02.559373+00	LSP8V2	EU868	1.0.3	A	lora_lr_fhss	NONE	3600	1	t	f	f	0	0	0	0	0	0	0	0	0	{}	/**\n * Decode uplink function\n * \n * @param {object} input\n * @param {number[]} input.bytes Byte array containing the uplink payload, e.g. [255, 230, 255, 0]\n * @param {number} input.fPort Uplink fPort.\n * @param {Record<string, string>} input.variables Object containing the configured device variables.\n * \n * @returns {{data: object}} Object representing the decoded payload.\n */\nfunction decodeUplink(input) {\n  return {\n    data: {\n      // temp: 22.5\n    }\n  };\n}\n\n/**\n * Encode downlink function.\n * \n * @param {object} input\n * @param {object} input.data Object representing the payload that must be encoded.\n * @param {Record<string, string>} input.variables Object containing the configured device variables.\n * \n * @returns {{bytes: number[]}} Byte array containing the downlink payload.\n */\nfunction encodeDownlink(input) {\n  return {\n    // bytes: [225, 230, 255, 0]\n  };\n}\n	t	gateway	{}	t	eu868	t	f	f	f	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	f	0
1f406b44-9ea4-45d5-888a-e4cbf16d04a7	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-25 13:55:45.39318+00	2025-04-02 07:28:09.679531+00	end-node LA66 meteo	EU868	1.0.3	A	default	JS	3600	1	t	f	f	0	0	0	0	0	0	0	0	0	{}	function decodeUplink(input) {\n    const bytes = input.bytes;\n    const port = input.fPort;\n    \n    const response = {\n        data: {},\n        warnings: [],\n        errors: []\n    };\n    \n    if (bytes.length < 17) {\n        response.errors.push("Not enough bytes in payload");\n        return response;\n    }\n    \n    try {\n        // Fonction pour convertir 4 octets en float\n        function bytesToFloat(bytes, startIndex) {\n            // Crée un ArrayBuffer de 4 octets\n            const buffer = new ArrayBuffer(4);\n            // Crée une vue sur ce buffer comme un tableau d'octets\n            const byteView = new Uint8Array(buffer);\n            // Copie les octets dans le buffer\n            for (let i = 0; i < 4; i++) {\n                byteView[i] = bytes[startIndex + i];\n            }\n            // Interprète le buffer comme un float\n            const floatView = new Float32Array(buffer);\n            return floatView[0];\n        }\n        \n        // Décode les valeurs\n        response.data.temperature = bytesToFloat(bytes, 0);\n        response.data.pressure = bytesToFloat(bytes, 4);\n        response.data.humidity = bytesToFloat(bytes, 8);\n        response.data.altitude = bytesToFloat(bytes, 12);\n        \n        // Décode l'état d'alerte\n        const alertState = bytes[16];\n        response.data.alertState = alertState;\n        \n        // Interprétation de l'état d'alerte\n        switch (alertState) {\n            case 0x01:\n                response.data.alertMessage = "Temperature Alert";\n                break;\n            case 0x02:\n                response.data.alertMessage = "Humidity Alert";\n                break;\n            case 0x03:\n                response.data.alertMessage = "Pressure Alert";\n                break;\n            case 0x06:\n                response.data.alertMessage = "Multiple Alerts";\n                break;\n            default:\n                response.data.alertMessage = "No Alert";\n        }\n        \n    } catch (error) {\n        response.errors.push("Decoding failed: " + error.message);\n    }\n    \n    return response;\n}	t		{"altitude": {"kind": "UNKNOWN", "name": ""}, "humidity": {"kind": "UNKNOWN", "name": ""}, "pressure": {"kind": "UNKNOWN", "name": ""}, "alertState": {"kind": "UNKNOWN", "name": ""}, "temperature": {"kind": "UNKNOWN", "name": ""}, "alertMessage": {"kind": "UNKNOWN", "name": ""}}	t	\N	f	f	f	f	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	f	0
87d0f0d9-2600-42e9-b4d4-5a7cf523656f	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-25 09:00:48.736643+00	2025-03-26 13:33:05.437122+00	end-node LA66 air quality	EU868	1.0.3	A	default	JS	3600	1	t	f	f	0	0	0	0	0	0	0	0	0	{}	// TTN V3 / ChirpStack V4 compatible decoder\nfunction decodeUplink(input) {\n    const { bytes, fPort: port } = input;\n\n    const response = {\n        data: {},\n        warnings: [],\n        errors: []\n    };\n\n    if (bytes.length < 7) {\n        response.errors.push("Not enough bytes in payload");\n        return response;\n    }\n\n    try {\n        const pm25 = (bytes[0] << 8) | bytes[1];\n        const pm10 = (bytes[2] << 8) | bytes[3];\n        const aqiValue = (bytes[4] << 8) | bytes[5];\n        const alertState = bytes[6];\n\n        response.data = {\n            pm25,\n            pm10,\n            aqiValue,\n            alertState,\n            alertPM25: Boolean(alertState & 1),\n            alertPM10: Boolean(alertState & 2),\n            alertAQI: Boolean(alertState & 4),\n            airQualityStatus: getAirQualityStatus(alertState)\n        };\n    } catch (error) {\n        response.errors.push(`Decoding failed: ${error.message}`);\n    }\n\n    return response;\n}\n\nfunction getAirQualityStatus(alertState) {\n    if (alertState === 0) return "Good";\n    if (alertState & 4) return "Very Poor";\n    if ((alertState & 1) && (alertState & 2)) return "Poor";\n    if ((alertState & 1) || (alertState & 2)) return "Moderate";\n    return "Unknown";\n}\n\n// Legacy TTN V2 decoder\nfunction Decoder(bytes, port) {\n    return decodeUplink({ bytes, fPort: port }).data;\n}\n	t		{"pm10": {"kind": "UNKNOWN", "name": ""}, "pm25": {"kind": "UNKNOWN", "name": ""}, "alertAQI": {"kind": "UNKNOWN", "name": ""}, "aqiValue": {"kind": "UNKNOWN", "name": ""}, "alertPM10": {"kind": "UNKNOWN", "name": ""}, "alertPM25": {"kind": "UNKNOWN", "name": ""}, "alertState": {"kind": "UNKNOWN", "name": ""}, "airQualityStatus": {"kind": "UNKNOWN", "name": ""}}	t	\N	f	f	f	f	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	f	0
b5c9b055-c364-41ae-87b9-267cf3ab1d76	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-19 10:26:37.205496+00	2025-03-31 08:43:08.119248+00	end-node LA66 parking	EU868	1.0.3	A	default	JS	3600	1	t	f	f	0	0	0	0	0	0	0	0	0	{}	/*\n* LORAWAN PARKING SENSOR DECODER\n* \n* This decoder handles data from a smart parking system with ultrasonic sensor\n* The payload consists of:\n* - 2 bytes: Occupancy time (seconds)\n* - 1 byte: Parking state (0 = FREE, 1 = OCCUPIED)\n*/\n\n// Modern format for TTN V3, ChirpStack V4, and other platforms\nfunction decodeUplink(input) {\n    var bytes = input.bytes;\n    var port = input.fPort;\n    var decoded = {};\n    \n    // Check if we have at least 3 bytes (2 for occupancy time, 1 for parking state)\n    if (bytes.length < 3) {\n        return {\n            data: {},\n            warnings: ["Payload too short"],\n            errors: ["Expected at least 3 bytes"]\n        };\n    }\n    \n    // Decode occupancy time (first 2 bytes) - time in seconds\n    var occupancyTime = (bytes[0] << 8) | bytes[1];\n    decoded.occupancyTime = occupancyTime;\n    \n    // Format as human-readable duration if occupied for more than a minute\n    if (occupancyTime >= 60) {\n        var hours = Math.floor(occupancyTime / 3600);\n        var minutes = Math.floor((occupancyTime % 3600) / 60);\n        var seconds = occupancyTime % 60;\n        \n        decoded.formattedOccupancyTime = '';\n        if (hours > 0) {\n            decoded.formattedOccupancyTime += hours + 'h ';\n        }\n        if (minutes > 0 || hours > 0) {\n            decoded.formattedOccupancyTime += minutes + 'm ';\n        }\n        decoded.formattedOccupancyTime += seconds + 's';\n    } else {\n        decoded.formattedOccupancyTime = occupancyTime + 's';\n    }\n    \n    // Decode parking state (last byte)\n    var parkingState = bytes[2];\n    decoded.parkingState = parkingState;\n    decoded.parkingStatus = (parkingState === 0) ? "FREE" : "OCCUPIED";\n    \n    // Add timestamp for when the message was received\n    decoded.timestamp = new Date().toISOString();\n    \n    return {\n        data: decoded,\n        warnings: [],\n        errors: []\n    };\n}\n\n// Keep the old format for backward compatibility\nfunction Decoder(bytes, port) {\n    var decoded = {};\n    \n    // Check if we have at least 3 bytes (2 for occupancy time, 1 for parking state)\n    if (bytes.length < 3) {\n        return decoded;\n    }\n    \n    // Decode occupancy time (first 2 bytes) - time in seconds\n    var occupancyTime = (bytes[0] << 8) | bytes[1];\n    decoded.occupancyTime = occupancyTime;\n    \n    // Format as human-readable duration if occupied for more than a minute\n    if (occupancyTime >= 60) {\n        var hours = Math.floor(occupancyTime / 3600);\n        var minutes = Math.floor((occupancyTime % 3600) / 60);\n        var seconds = occupancyTime % 60;\n        \n        decoded.formattedOccupancyTime = '';\n        if (hours > 0) {\n            decoded.formattedOccupancyTime += hours + 'h ';\n        }\n        if (minutes > 0 || hours > 0) {\n            decoded.formattedOccupancyTime += minutes + 'm ';\n        }\n        decoded.formattedOccupancyTime += seconds + 's';\n    } else {\n        decoded.formattedOccupancyTime = occupancyTime + 's';\n    }\n    \n    // Decode parking state (last byte)\n    var parkingState = bytes[2];\n    decoded.parkingState = parkingState;\n    decoded.parkingStatus = (parkingState === 0) ? "FREE" : "OCCUPIED";\n    \n    // Add timestamp for when the message was received\n    decoded.timestamp = new Date().toISOString();\n    \n    return decoded;\n}	t		{"timestamp": {"kind": "UNKNOWN", "name": ""}, "parkingState": {"kind": "UNKNOWN", "name": ""}, "occupancyTime": {"kind": "UNKNOWN", "name": ""}, "parkingStatus": {"kind": "UNKNOWN", "name": ""}, "formattedOccupancyTime": {"kind": "UNKNOWN", "name": ""}}	t	\N	f	f	f	f	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	f	0
\.


--
-- Data for Name: device_profile_template; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.device_profile_template (id, created_at, updated_at, name, description, vendor, firmware, region, mac_version, reg_params_revision, adr_algorithm_id, payload_codec_runtime, payload_codec_script, uplink_interval, device_status_req_interval, flush_queue_on_activate, supports_otaa, supports_class_b, supports_class_c, class_b_timeout, class_b_ping_slot_nb_k, class_b_ping_slot_dr, class_b_ping_slot_freq, class_c_timeout, abp_rx1_delay, abp_rx1_dr_offset, abp_rx2_dr, abp_rx2_freq, tags, measurements, auto_detect_measurements) FROM stdin;
LA66	2025-03-19 10:24:40.346687+00	2025-03-19 10:24:40.346687+00	end-node LA66		dragino	1.0	EU868	1.0.3	A	default	NONE	/**\n * Decode uplink function\n * \n * @param {object} input\n * @param {number[]} input.bytes Byte array containing the uplink payload, e.g. [255, 230, 255, 0]\n * @param {number} input.fPort Uplink fPort.\n * @param {Record<string, string>} input.variables Object containing the configured device variables.\n * \n * @returns {{data: object}} Object representing the decoded payload.\n */\nfunction decodeUplink(input) {\n  return {\n    data: {\n      // temp: 22.5\n    }\n  };\n}\n\n/**\n * Encode downlink function.\n * \n * @param {object} input\n * @param {object} input.data Object representing the payload that must be encoded.\n * @param {Record<string, string>} input.variables Object containing the configured device variables.\n * \n * @returns {{bytes: number[]}} Byte array containing the downlink payload.\n */\nfunction encodeDownlink(input) {\n  return {\n    // bytes: [225, 230, 255, 0]\n  };\n}\n	3600	1	t	t	f	f	0	0	0	0	0	0	0	0	0	{}	{}	t
\.


--
-- Data for Name: device_queue_item; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.device_queue_item (id, dev_eui, created_at, f_port, confirmed, data, is_pending, f_cnt_down, timeout_after, is_encrypted, expires_at) FROM stdin;
\.


--
-- Data for Name: gateway; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.gateway (gateway_id, tenant_id, created_at, updated_at, last_seen_at, name, description, latitude, longitude, altitude, stats_interval_secs, tls_certificate, tags, properties) FROM stdin;
\\xa84041fdfe275f7a	52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-19 09:25:42.497366+00	2025-03-26 12:47:42.574593+00	2025-04-08 14:02:46.323826+00	gateway-lora		0	0	0	10	\N	{}	{"region_config_id": "eu868", "region_common_name": "EU868"}
\.


--
-- Data for Name: multicast_group; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.multicast_group (id, application_id, created_at, updated_at, name, region, mc_addr, mc_nwk_s_key, mc_app_s_key, f_cnt, group_type, dr, frequency, class_b_ping_slot_nb_k, class_c_scheduling_type) FROM stdin;
\.


--
-- Data for Name: multicast_group_device; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.multicast_group_device (multicast_group_id, dev_eui, created_at) FROM stdin;
\.


--
-- Data for Name: multicast_group_gateway; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.multicast_group_gateway (multicast_group_id, gateway_id, created_at) FROM stdin;
\.


--
-- Data for Name: multicast_group_queue_item; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.multicast_group_queue_item (id, created_at, scheduler_run_after, multicast_group_id, gateway_id, f_cnt, f_port, data, emit_at_time_since_gps_epoch, expires_at) FROM stdin;
\.


--
-- Data for Name: relay_device; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.relay_device (relay_dev_eui, dev_eui, created_at) FROM stdin;
\.


--
-- Data for Name: relay_gateway; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.relay_gateway (tenant_id, relay_id, created_at, updated_at, last_seen_at, name, description, stats_interval_secs, region_config_id) FROM stdin;
\.


--
-- Data for Name: tenant; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.tenant (id, created_at, updated_at, name, description, can_have_gateways, max_device_count, max_gateway_count, private_gateways_up, private_gateways_down, tags) FROM stdin;
52f14cd4-c6f1-4fbd-8f87-4025e1d49242	2025-03-19 09:22:31.869593+00	2025-03-19 09:22:31.869593+00	ChirpStack		t	0	0	f	f	{}
\.


--
-- Data for Name: tenant_user; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public.tenant_user (tenant_id, user_id, created_at, updated_at, is_admin, is_device_admin, is_gateway_admin) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: chirpstack
--

COPY public."user" (id, external_id, created_at, updated_at, is_admin, is_active, email, email_verified, password_hash, note) FROM stdin;
05244f12-6daf-4e1f-8315-c66783a0ab56	\N	2025-03-19 09:22:31.869593+00	2025-03-19 09:22:31.869593+00	t	t	admin	f	$pbkdf2-sha512$i=1,l=64$l8zGKtxRESq3PA2kFhHRWA$H3lGMxOt55wjwoc+myeOoABofJY9oDpldJa7fhqdjbh700V6FLPML75UmBOt9J5VFNjAL1AvqCozA1HJM0QVGA	
\.


--
-- Name: __diesel_schema_migrations __diesel_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.__diesel_schema_migrations
    ADD CONSTRAINT __diesel_schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: application_integration application_integration_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.application_integration
    ADD CONSTRAINT application_integration_pkey PRIMARY KEY (application_id, kind);


--
-- Name: application application_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.application
    ADD CONSTRAINT application_pkey PRIMARY KEY (id);


--
-- Name: device_keys device_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_keys
    ADD CONSTRAINT device_keys_pkey PRIMARY KEY (dev_eui);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (dev_eui);


--
-- Name: device_profile device_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_profile
    ADD CONSTRAINT device_profile_pkey PRIMARY KEY (id);


--
-- Name: device_profile_template device_profile_template_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_profile_template
    ADD CONSTRAINT device_profile_template_pkey PRIMARY KEY (id);


--
-- Name: device_queue_item device_queue_item_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_queue_item
    ADD CONSTRAINT device_queue_item_pkey PRIMARY KEY (id);


--
-- Name: gateway gateway_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.gateway
    ADD CONSTRAINT gateway_pkey PRIMARY KEY (gateway_id);


--
-- Name: multicast_group_device multicast_group_device_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_device
    ADD CONSTRAINT multicast_group_device_pkey PRIMARY KEY (multicast_group_id, dev_eui);


--
-- Name: multicast_group_gateway multicast_group_gateway_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_gateway
    ADD CONSTRAINT multicast_group_gateway_pkey PRIMARY KEY (multicast_group_id, gateway_id);


--
-- Name: multicast_group multicast_group_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group
    ADD CONSTRAINT multicast_group_pkey PRIMARY KEY (id);


--
-- Name: multicast_group_queue_item multicast_group_queue_item_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_queue_item
    ADD CONSTRAINT multicast_group_queue_item_pkey PRIMARY KEY (id);


--
-- Name: relay_device relay_device_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.relay_device
    ADD CONSTRAINT relay_device_pkey PRIMARY KEY (relay_dev_eui, dev_eui);


--
-- Name: relay_gateway relay_gateway_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.relay_gateway
    ADD CONSTRAINT relay_gateway_pkey PRIMARY KEY (tenant_id, relay_id);


--
-- Name: tenant tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.tenant
    ADD CONSTRAINT tenant_pkey PRIMARY KEY (id);


--
-- Name: tenant_user tenant_user_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.tenant_user
    ADD CONSTRAINT tenant_user_pkey PRIMARY KEY (tenant_id, user_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: idx_api_key_tenant_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_api_key_tenant_id ON public.api_key USING btree (tenant_id);


--
-- Name: idx_application_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_application_name_trgm ON public.application USING gin (name public.gin_trgm_ops);


--
-- Name: idx_application_tags; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_application_tags ON public.application USING gin (tags);


--
-- Name: idx_application_tenant_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_application_tenant_id ON public.application USING btree (tenant_id);


--
-- Name: idx_device_application_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_application_id ON public.device USING btree (application_id);


--
-- Name: idx_device_dev_addr; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_dev_addr ON public.device USING btree (dev_addr);


--
-- Name: idx_device_dev_addr_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_dev_addr_trgm ON public.device USING gin (encode(dev_addr, 'hex'::text) public.gin_trgm_ops);


--
-- Name: idx_device_dev_eui_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_dev_eui_trgm ON public.device USING gin (encode(dev_eui, 'hex'::text) public.gin_trgm_ops);


--
-- Name: idx_device_device_profile_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_device_profile_id ON public.device USING btree (device_profile_id);


--
-- Name: idx_device_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_name_trgm ON public.device USING gin (name public.gin_trgm_ops);


--
-- Name: idx_device_profile_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_profile_name_trgm ON public.device_profile USING gin (name public.gin_trgm_ops);


--
-- Name: idx_device_profile_tags; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_profile_tags ON public.device_profile USING gin (tags);


--
-- Name: idx_device_profile_tenant_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_profile_tenant_id ON public.device_profile USING btree (tenant_id);


--
-- Name: idx_device_queue_item_created_at; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_queue_item_created_at ON public.device_queue_item USING btree (created_at);


--
-- Name: idx_device_queue_item_dev_eui; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_queue_item_dev_eui ON public.device_queue_item USING btree (dev_eui);


--
-- Name: idx_device_queue_item_timeout_after; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_queue_item_timeout_after ON public.device_queue_item USING btree (timeout_after);


--
-- Name: idx_device_secondary_dev_addr; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_secondary_dev_addr ON public.device USING btree (secondary_dev_addr);


--
-- Name: idx_device_tags; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_device_tags ON public.device USING gin (tags);


--
-- Name: idx_gateway_id_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_gateway_id_trgm ON public.gateway USING gin (encode(gateway_id, 'hex'::text) public.gin_trgm_ops);


--
-- Name: idx_gateway_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_gateway_name_trgm ON public.gateway USING gin (name public.gin_trgm_ops);


--
-- Name: idx_gateway_tags; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_gateway_tags ON public.gateway USING gin (tags);


--
-- Name: idx_gateway_tenant_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_gateway_tenant_id ON public.gateway USING btree (tenant_id);


--
-- Name: idx_multicast_group_application_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_multicast_group_application_id ON public.multicast_group USING btree (application_id);


--
-- Name: idx_multicast_group_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_multicast_group_name_trgm ON public.multicast_group USING gin (name public.gin_trgm_ops);


--
-- Name: idx_multicast_group_queue_item_multicast_group_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_multicast_group_queue_item_multicast_group_id ON public.multicast_group_queue_item USING btree (multicast_group_id);


--
-- Name: idx_multicast_group_queue_item_scheduler_run_after; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_multicast_group_queue_item_scheduler_run_after ON public.multicast_group_queue_item USING btree (scheduler_run_after);


--
-- Name: idx_tenant_name_trgm; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_tenant_name_trgm ON public.tenant USING gin (name public.gin_trgm_ops);


--
-- Name: idx_tenant_tags; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_tenant_tags ON public.tenant USING gin (tags);


--
-- Name: idx_tenant_user_user_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE INDEX idx_tenant_user_user_id ON public.tenant_user USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE UNIQUE INDEX idx_user_email ON public."user" USING btree (email);


--
-- Name: idx_user_external_id; Type: INDEX; Schema: public; Owner: chirpstack
--

CREATE UNIQUE INDEX idx_user_external_id ON public."user" USING btree (external_id);


--
-- Name: api_key api_key_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: application_integration application_integration_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.application_integration
    ADD CONSTRAINT application_integration_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.application(id) ON DELETE CASCADE;


--
-- Name: application application_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.application
    ADD CONSTRAINT application_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: device device_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.application(id) ON DELETE CASCADE;


--
-- Name: device device_device_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_device_profile_id_fkey FOREIGN KEY (device_profile_id) REFERENCES public.device_profile(id) ON DELETE CASCADE;


--
-- Name: device_keys device_keys_dev_eui_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_keys
    ADD CONSTRAINT device_keys_dev_eui_fkey FOREIGN KEY (dev_eui) REFERENCES public.device(dev_eui) ON DELETE CASCADE;


--
-- Name: device_profile device_profile_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_profile
    ADD CONSTRAINT device_profile_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: device_queue_item device_queue_item_dev_eui_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.device_queue_item
    ADD CONSTRAINT device_queue_item_dev_eui_fkey FOREIGN KEY (dev_eui) REFERENCES public.device(dev_eui) ON DELETE CASCADE;


--
-- Name: gateway gateway_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.gateway
    ADD CONSTRAINT gateway_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: multicast_group multicast_group_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group
    ADD CONSTRAINT multicast_group_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.application(id) ON DELETE CASCADE;


--
-- Name: multicast_group_device multicast_group_device_dev_eui_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_device
    ADD CONSTRAINT multicast_group_device_dev_eui_fkey FOREIGN KEY (dev_eui) REFERENCES public.device(dev_eui) ON DELETE CASCADE;


--
-- Name: multicast_group_device multicast_group_device_multicast_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_device
    ADD CONSTRAINT multicast_group_device_multicast_group_id_fkey FOREIGN KEY (multicast_group_id) REFERENCES public.multicast_group(id) ON DELETE CASCADE;


--
-- Name: multicast_group_gateway multicast_group_gateway_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_gateway
    ADD CONSTRAINT multicast_group_gateway_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateway(gateway_id) ON DELETE CASCADE;


--
-- Name: multicast_group_gateway multicast_group_gateway_multicast_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_gateway
    ADD CONSTRAINT multicast_group_gateway_multicast_group_id_fkey FOREIGN KEY (multicast_group_id) REFERENCES public.multicast_group(id) ON DELETE CASCADE;


--
-- Name: multicast_group_queue_item multicast_group_queue_item_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_queue_item
    ADD CONSTRAINT multicast_group_queue_item_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateway(gateway_id) ON DELETE CASCADE;


--
-- Name: multicast_group_queue_item multicast_group_queue_item_multicast_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.multicast_group_queue_item
    ADD CONSTRAINT multicast_group_queue_item_multicast_group_id_fkey FOREIGN KEY (multicast_group_id) REFERENCES public.multicast_group(id) ON DELETE CASCADE;


--
-- Name: relay_device relay_device_dev_eui_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.relay_device
    ADD CONSTRAINT relay_device_dev_eui_fkey FOREIGN KEY (dev_eui) REFERENCES public.device(dev_eui) ON DELETE CASCADE;


--
-- Name: relay_device relay_device_relay_dev_eui_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.relay_device
    ADD CONSTRAINT relay_device_relay_dev_eui_fkey FOREIGN KEY (relay_dev_eui) REFERENCES public.device(dev_eui) ON DELETE CASCADE;


--
-- Name: relay_gateway relay_gateway_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.relay_gateway
    ADD CONSTRAINT relay_gateway_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: tenant_user tenant_user_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.tenant_user
    ADD CONSTRAINT tenant_user_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenant(id) ON DELETE CASCADE;


--
-- Name: tenant_user tenant_user_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chirpstack
--

ALTER TABLE ONLY public.tenant_user
    ADD CONSTRAINT tenant_user_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17
-- Dumped by pg_dump version 14.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

